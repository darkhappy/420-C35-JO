#include <string>

using namespace std;

class Note {
private:
	string name;
	string content;

public:
	// TODO : Impl�mentation des m�thodes n�cessaires
};
