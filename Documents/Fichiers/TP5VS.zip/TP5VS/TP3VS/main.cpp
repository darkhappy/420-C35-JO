#pragma comment(lib, "420C35JOTP5Lib.lib")

#ifdef _DEBUG
  #undef _DEBUG
  #include "Window.hpp"
  #define _DEBUG
#else
  #include "Window.hpp"
#endif
#include "TP5.hpp"

int main(int argc, char* argv[]) {
	return Window::open(onInit, onMenuClick, onRefresh, onWindowClick, onQuit);
}
